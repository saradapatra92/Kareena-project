package com.cts.helper;

import org.apache.log4j.Logger;

import com.cts.beans.Passenger;
import com.cts.dao.PassengerDetailsDao;

public class PassengerDetailsBo {

	private  static Logger logger = Logger.getLogger(PassengerDetailsBo.class);
	
	public static String deletePassenger(){
		logger.info("Checking addPassenger method...");
		PassengerDetailsDao daoPassenger=new PassengerDetailsDao(); 
		return daoPassenger.deletePassenger();
	}
	
	public static String addPassenger(Passenger p){
		logger.info("Checking addPassenger method...");
		PassengerDetailsDao daoPassenger=new PassengerDetailsDao(); 
		logger.info("addPassenger Method Executed Successfully...");
		return daoPassenger.addPassenger(p);
	}
	
	public static Passenger searchPassenger(String pnr){
		logger.info("Checking searchPassenger method...");
		PassengerDetailsDao daoPassenger=new PassengerDetailsDao();
		logger.info("searchPassenger Method Executed Successfully...");
		return daoPassenger.searchPassenger(pnr);
	}
	
	public static String getPnr() {
		logger.info("Checking getPnr method...");
		PassengerDetailsDao daoPassenger=new PassengerDetailsDao();
		logger.info("getPnr Method Executed Successfully...");
		return daoPassenger.getPnr();
	}
}
