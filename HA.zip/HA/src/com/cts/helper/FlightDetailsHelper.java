package com.cts.helper;

import java.sql.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.cts.beans.Flights;
import com.cts.beans.Ticket;
import com.cts.dao.FlightDetailsDao;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;
import com.cts.utilities.PropertyUtil;

public class FlightDetailsHelper {

	private  static Logger logger = Logger.getLogger(FlightDetailsHelper.class);
	public static boolean TicketExists(String ticketNo){
		logger.info("Checking TicketExists method...");
		FlightDetailsDao objFlightsDao=new FlightDetailsDao(); 
		boolean res=false;
		try {
			res=objFlightsDao.TicketExists(ticketNo);
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			logger.error(PropertyUtil.getMessage(e.getMessage()));
			e.printStackTrace();
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			logger.error(PropertyUtil.getMessage(e.getMessage()));
			e.printStackTrace();
		}
		logger.info("TicketExists Method Executed Successfully...");
		return res;
	}
	
	public static String getTicketNo() {
		logger.info("Calling getTicketNo() Method...");
		FlightDetailsDao objFlightsDao=new FlightDetailsDao(); 
		String res="";
		try {
			res=objFlightsDao.getTicketNo();
		} catch (ValidationException | DatabaseException e) {
			logger.error(PropertyUtil.getMessage(e.getMessage()));
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("getTicketNo() Method Executed Successfully...");
		return res;
	}
	
	public static String cancelTicket(String ticketNo){
		logger.info("Calling cancelTicket() Method...");
		FlightDetailsDao objFlightsDao=new FlightDetailsDao(); 
		String res="";
		try {
			res=objFlightsDao.cancelTicket(ticketNo);
		} catch (ValidationException e) {
			logger.error(PropertyUtil.getMessage(e.getMessage()));
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DatabaseException e) {
			logger.error(PropertyUtil.getMessage(e.getMessage()));
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("cancelTicket() Method Executed Successfully...");
		return res;
	}
	
	public static String bookFlight(Ticket objTicket){
		logger.info("Calling bookFlight() Method...");
	//public static String booKflight(String flightId,String custName,int noOfPassengers,double billAmount,String source,String destination){
		FlightDetailsDao objFlightsDao=new FlightDetailsDao(); 
		String res="";
		try {
			res=objFlightsDao.booKflight(objTicket);
		} catch (ValidationException | DatabaseException e) {
			logger.error(PropertyUtil.getMessage(e.getMessage()));
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("bookFlight() Method Executed Successfully...");
		return res;
	}
	
	public static List<Flights> searchFlights(Date journeyDate, String source,
			String destination) throws ValidationException, DatabaseException {
		logger.info("Calling searchFlights() Method...");
		FlightDetailsDao objFlightsDao=new FlightDetailsDao(); 
		logger.info("searchFlights() Method Executed Successfully...");
		return objFlightsDao.searchFlights(journeyDate, source, destination);
	}
	
	public static boolean flightExists(String flightId, Date date) {
		logger.info("Calling flightExists() Method...");
		FlightDetailsDao objFlightsDao=new FlightDetailsDao();  
		boolean res=true;
		try {
			res=objFlightsDao.flightExists(flightId, date);
		} catch (ValidationException | DatabaseException e) {
			logger.error(PropertyUtil.getMessage(e.getMessage()));
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("flightExists() Method Executed Successfully...");
		return res;
	}
	
	public static boolean addFlights(Flights objFlights) {
		logger.info("Calling addFlights() Method...");
		FlightDetailsDao objFlightsDao=new FlightDetailsDao();  
		boolean res=true;
		try {
			res=objFlightsDao.addFlights(objFlights);
		} catch (ValidationException | DatabaseException e) {
			logger.error(PropertyUtil.getMessage(e.getMessage()));
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("addFlights() Method Executed Successfully...");
		return res;
	}
	
	public static Flights searchFlight(String flightId) throws ValidationException, DatabaseException {
		logger.info("Calling searchFlight() Method...");
		FlightDetailsDao objFlightsDao=new FlightDetailsDao();
		logger.info("searchFlight() Method Executed Successfully...");
		return objFlightsDao.searchFlight(flightId);
	}
	
	public static boolean planeExists(String flightId) {
		logger.info("Calling planeExists() Method...");
		FlightDetailsDao objFlightsDao=new FlightDetailsDao();
		boolean res=true;
		try {
			res=objFlightsDao.planeExists(flightId);
		} catch (ValidationException e) {
			logger.error(PropertyUtil.getMessage(e.getMessage()));
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DatabaseException e) {
			logger.error(PropertyUtil.getMessage(e.getMessage()));
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("planeExists() Method Executed Successfully...");
		return res;
	}
	
	public static boolean flightUpdate(Flights fAdmin) {
		logger.info("Calling flightUpdate() Method...");
		FlightDetailsDao objFlightsDao=new FlightDetailsDao();
		boolean res=false;
		try {
			res=objFlightsDao.flightUpdate(fAdmin);
		} catch (ValidationException e) {
			logger.error(PropertyUtil.getMessage(e.getMessage()));
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DatabaseException e) {
			logger.error(PropertyUtil.getMessage(e.getMessage()));
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("flightUpdate() Method Executed Successfully...");
		return res;
	}
	
	public static boolean flightExistsDelete(String flightId) {
		logger.info("Calling flightExistsDelete() Method...");
		FlightDetailsDao objFlightsDao=new FlightDetailsDao();
		boolean res=true;
		try {
			res=objFlightsDao.flightExistsDelete(flightId);
		} catch (ValidationException e) {
			logger.error(PropertyUtil.getMessage(e.getMessage()));
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DatabaseException e) {
			logger.error(PropertyUtil.getMessage(e.getMessage()));
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("flightExistsDelete() Method Executed Successfully...");
		return res;
	}
	
	public static boolean deleteFlights(Flights objFlights) throws ValidationException, DatabaseException {
		logger.info("Calling deleteFlights() Method...");
		FlightDetailsDao objFlightsDao=new FlightDetailsDao();
		logger.info("deleteFlights() Method Executed Successfully...");
		return objFlightsDao.deleteFlights(objFlights);
	}
}
