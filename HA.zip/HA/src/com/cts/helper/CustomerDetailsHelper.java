package com.cts.helper;

import org.apache.log4j.Logger;

import com.cts.beans.Customer;
import com.cts.dao.CustomerDetailsDao;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;
import com.cts.utilities.PropertyUtil;

public class CustomerDetailsHelper {

	private  static Logger logger = Logger.getLogger(CustomerDetailsHelper.class);
	public static boolean authenticate(String email,String passWord){
		logger.info("CustomerHelper Class Authenticate method...");
		boolean result=false;
		try {
			CustomerDetailsDao objCustomerDao=new CustomerDetailsDao();
			result=objCustomerDao.authenticate(email, passWord);
			
		}
		catch (ValidationException ve) {
			logger.error(PropertyUtil.getMessage(ve.getMessage()));
			ve.printStackTrace();
		
		}catch(DatabaseException de){
			logger.error(PropertyUtil.getMessage(de.getMessage()));
			System.out.println(PropertyUtil.getMessage(de.getMessage()));
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("CustomerHelper Class Authenticate method executed Successfully...");
		return result;
	}
	
	public static boolean userExists(String email) {
		logger.info("CustomerHelper Class userExists method...");
		CustomerDetailsDao objCustomerDao=new CustomerDetailsDao();
		boolean result=false;
		try {
			result = objCustomerDao.userExists(email);
		} catch (ValidationException | DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	public static String getCustomerName(String email) {
		logger.info("CustomerHelper Class getCustomerName method...");
		CustomerDetailsDao objCustomerDao=new CustomerDetailsDao();
		String res="";
		try {
			res=objCustomerDao.getCustomerName(email);
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
	
	public static boolean addCustomer(Customer objCustomer) {
		logger.info("CustomerHelper Class addCustomer method...");
		CustomerDetailsDao objCustomerDao=new CustomerDetailsDao();
		boolean result=false;
		try {
			result=objCustomerDao.addCustomer(objCustomer);
		} catch (ValidationException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	
}
