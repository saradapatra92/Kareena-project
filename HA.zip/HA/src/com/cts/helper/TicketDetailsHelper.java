package com.cts.helper;

import java.sql.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.cts.beans.Flights;
import com.cts.beans.Ticket;
import com.cts.dao.FlightDetailsDao;
import com.cts.dao.TicketDetailsDao;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;

public class TicketDetailsHelper {

	private  static Logger logger = Logger.getLogger(TicketDetailsHelper.class);
	public static List<Ticket> showTickets(String user) throws ValidationException, DatabaseException{
		logger.info("Checking showTickets method...");
		TicketDetailsDao objTicketDao=new TicketDetailsDao(); 
		logger.info("showTickets Method Executed Successfully...");
		return objTicketDao.showTickets(user);
	}
}


