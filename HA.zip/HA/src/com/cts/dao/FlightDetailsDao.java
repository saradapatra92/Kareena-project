package com.cts.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cts.beans.Customer;
import com.cts.beans.Flights;
import com.cts.beans.Ticket;
import com.cts.datasource.SingleTonConnection;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;
import com.cts.utilities.PropertyUtil;



public class FlightDetailsDao {
	
	private  static Logger logger = Logger.getLogger(FlightDetailsDao.class);
	public boolean TicketExists(String ticketNo) throws ValidationException,DatabaseException
	{
		boolean flag = false;
		String userCmd = "select TicketNo  from bookedhistory where TicketNo=?";
		Connection con = SingleTonConnection.getInstance().getConnection();
		try {
			PreparedStatement pst = con.prepareStatement(userCmd);
			pst.setString(1, ticketNo);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				flag = true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		return flag;
	}

	
	public String getTicketNo() throws ValidationException,DatabaseException {
		Connection con = SingleTonConnection.getInstance().getConnection();
		String cmd="select max(ticketno) tno from bookedHistory";
		String msg="";
		try {
			PreparedStatement pst=con.prepareStatement(cmd);
			ResultSet rs=pst.executeQuery(); 
			rs.next();
			msg=rs.getString("tno");
			return msg;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			msg=e.getMessage();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		return msg;
	}
	
	public String cancelTicket(String ticketNo) throws ValidationException,DatabaseException{
		Connection con = SingleTonConnection.getInstance().getConnection();
		String msg="";
		int p=0;
		String cmd="select * from BookedHistory where TicketNo=?";
		try {
			PreparedStatement pst=con.prepareStatement(cmd);
			pst.setString(1, ticketNo);
			ResultSet rs=pst.executeQuery();
			
		
			if(rs.next()){
				p=rs.getInt("NoOfPassengers");
				String fid=rs.getString("FlightId");
				cmd="update BookedHistory set BookStatus='Cancelled' where TicketNo=?";
				pst=con.prepareStatement(cmd);
				pst.setString(1, ticketNo);
				pst.executeUpdate();
				cmd="update flights set seats=seats+? where flightID=?";
				pst=con.prepareStatement(cmd);
				pst.setInt(1,p);
				pst.setString(2,fid);
				pst.executeUpdate();
				msg="Ticket Cancelled Successfully...";
			}
			else {
				msg="Ticket Not Found";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			msg=e.getMessage();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		return msg;
	}
	
	public String booKflight(Ticket objTicket) throws ValidationException,DatabaseException{
	//public String booKflight(String flightId,String custName,int noOfPassengers,double billAmount,String source,String destination) throws ValidationException,DatabaseException{
		System.out.println("No.of Passengers  " +objTicket.getNoOfPassengers());
		String cmdTicket="select count(*) cnt from BookedHistory";
		String dummy="";
		java.util.Date dt=new java.util.Date();
		int m=dt.getMonth();
		m++;
		dummy+="TKTM"+m+"D"+dt.getDate()+"A";
		String ticketNo="";
	//	System.out.println(ticketNo);
		Connection con = SingleTonConnection.getInstance().getConnection();
		try {
			PreparedStatement pstTicket=con.prepareStatement(cmdTicket);
			ResultSet rs=pstTicket.executeQuery();
			rs.next();
			int cnt=rs.getInt("cnt");
			if(cnt==0){
				ticketNo=dummy+"001";
			}
			else {
				cmdTicket="select TicketNo from BookedHistory";
				pstTicket=con.prepareStatement(cmdTicket);
				rs=pstTicket.executeQuery();
				while(rs.next()){
					ticketNo=rs.getString("TicketNo");
				}
				
				int x=ticketNo.indexOf("A");
				x++;
				
				System.out.println(ticketNo.substring(x));
				int no=Integer.parseInt(ticketNo.substring(x));
				
				no++;
				if(no >=1 && no <= 9){
					ticketNo=dummy+"00"+no;
				}
				if(no >= 10 && no <= 99){
					ticketNo=dummy+"0"+no;
				}
				if(no >= 100 && no <= 1000){
					ticketNo=dummy+no;
				}
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			logger.error(PropertyUtil.getMessage(e1.getMessage()));
		}
		 
		//String customer="Kareena";
		//custName="Kareena";
		Flights f=new FlightDetailsDao().searchFlight(objTicket.getFlightId());
		int avail=f.getSeats();
		int bal=avail-objTicket.getNoOfPassengers();
		System.out.println("Available Seats  " +avail);
		System.out.println("Balance  " +bal);
		String result="";
		if(avail-objTicket.getNoOfPassengers() >= 0){
			String cmd="insert into BookedHistory(FlightID,CustomerName,NoOfPassengers,BillAmount,TicketNo,Source,Destination,dateOfJourney) "
					+ " values(?,?,?,?,?,?,?,?)";
		
			try {
				PreparedStatement pst=con.prepareStatement(cmd);
				pst.setString(1, objTicket.getFlightId());
				pst.setString(2, objTicket.getCustomerName());
				pst.setInt(3, objTicket.getNoOfPassengers());
				pst.setDouble(4, objTicket.getBillAmount());
				pst.setString(5, ticketNo);
				pst.setString(6, objTicket.getSource());
				pst.setString(7, objTicket.getDestination());
				pst.setDate(8,objTicket.getDateOfJourney());
				pst.executeUpdate();
				cmd="update flights set seats=? where flightID=?"; 
				pst=con.prepareStatement(cmd);
				pst.setInt(1, avail-objTicket.getNoOfPassengers());
				pst.setString(2, objTicket.getFlightId());
				pst.executeUpdate(); 
				result="Ticket Booked Successfully ";
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));
				result=e.getMessage();
			}
		}
		else {
			result="No Booking Allowed...No Seats";
		}
		return result;
	}
	
	public List<Flights> searchFlights(Date journeyDate, String source,
			String destination) throws ValidationException,DatabaseException {
		String sqlCmdcount = "select count(*) cnt from Flights where departureDate=? AND source=? AND destination=? AND seats > 0";
		String sqlCmd = "select * from flights where departureDate=? AND source=? AND destination=? AND seats > 0";
		Connection con = SingleTonConnection.getInstance().getConnection();
		List<Flights> flights = new ArrayList<Flights>();
		try {
			PreparedStatement pst = con.prepareStatement(sqlCmdcount);
			System.out.println(journeyDate + " " +source + " " +destination);
			pst.setDate(1, journeyDate);
			pst.setString(2, source);
			pst.setString(3, destination);
			ResultSet rs = pst.executeQuery();
			rs.next();
			int count = rs.getInt("cnt");
			System.out.println(count);
			if (count == 0) {
				flights = null;
			} else {
				//flights = new Flights[count];
				pst = con.prepareStatement(sqlCmd);
				pst.setDate(1, journeyDate);
				pst.setString(2, source);
				pst.setString(3, destination);
				rs = pst.executeQuery();
				Flights f = null;
				int i = 0;
				int s=0;
				while (rs.next()) {
				
				
					f = new Flights();
					f.setFlightId(rs.getString("FlightID"));
					f.setCompanyName(rs.getString("CompanyName"));
					f.setSource(rs.getString("source"));
					f.setDestination(rs.getString("destination"));
					f.setDepartureDate(rs.getDate("departureDate"));
					f.setDepartureTime(rs.getString("DepartureTime"));
					f.setArrivalTime(rs.getString("ArrivalTime"));
					f.setPrice(rs.getDouble("Price"));
					f.setSeats(rs.getInt("seats"));
				//	System.out.println(f.getSeats());
					flights.add(f);
					i++;
				
				}
			}
		} catch (SQLException e) {
		
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}

		return flights;
	}

	public boolean flightExists(String flightId, Date date) throws ValidationException,DatabaseException {
		boolean flag = false;
		String userCmd = "select flightId,departureDate from flights where flightId=?";
		Connection con = SingleTonConnection.getInstance().getConnection();
		try {
			PreparedStatement pst = con.prepareStatement(userCmd);
			pst.setString(1, flightId);
		//	pst.setDate(2, date);

			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				flag = true;
			}
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		return flag;
	}

	public boolean addFlights(Flights objFlights) throws ValidationException, DatabaseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		boolean msg = false;
		boolean flag = flightExists(objFlights.getFlightId(),
				objFlights.getDepartureDate());
		
		if (flag == false) {
			Connection con = SingleTonConnection.getInstance().getConnection();
			String cmdFlightIns = "Insert into flights(FlightID,CompanyName,source,destination,departureDate,DepartureTime,ArrivalTime,price,seats) values(?,?,?,?,?,?,?,?,?)";
			try {
				PreparedStatement pst = con.prepareStatement(cmdFlightIns);
				pst.setString(1, objFlights.getFlightId());
				pst.setString(2, objFlights.getCompanyName());
				pst.setString(3, objFlights.getSource());
				pst.setString(4, objFlights.getDestination());
				pst.setDate(5, objFlights.getDepartureDate());
				pst.setString(6, objFlights.getArrivalTime());
				pst.setString(7, objFlights.getDepartureTime());
				pst.setDouble(8, objFlights.getPrice());
				pst.setInt(9, objFlights.getSeats());
				int n = pst.executeUpdate();
				if (n > 0) {
					msg = true;
				}

			} catch (SQLException e) {
				
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));
			}
		}
		return msg;
	}

	public Flights searchFlight(String flightId) throws ValidationException,DatabaseException {
		Connection con = SingleTonConnection.getInstance().getConnection();
		String strcmd = "select * from flights where flightId=?";
		Flights f = null;
		try {
			PreparedStatement pst = con.prepareStatement(strcmd);
			pst.setString(1, flightId);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				f = new Flights();
				f.setFlightId(rs.getString("FlightID"));
				f.setCompanyName(rs.getString("CompanyName"));
				f.setSource(rs.getString("source"));
				f.setDestination(rs.getString("destination"));
				f.setDepartureDate(rs.getDate("departureDate"));
				f.setDepartureTime(rs.getString("DepartureTime"));
				f.setArrivalTime(rs.getString("ArrivalTime"));
				f.setPrice(rs.getDouble("Price"));
				f.setSeats(rs.getInt("seats"));
			}
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		return f;
	}

	public boolean planeExists(String flightId) throws ValidationException,DatabaseException {
		boolean flag = false;
		String userCmd = "select FlightID from flights where FlightID=?";
		Connection con = SingleTonConnection.getInstance().getConnection();
		try {
			PreparedStatement pst = con.prepareStatement(userCmd);
			pst.setString(1, flightId);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				flag = true;
			}
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		return flag;
	}

	public boolean flightUpdate(Flights fAdmin) throws ValidationException, DatabaseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		boolean msg = false;
		boolean flag = planeExists(fAdmin.getFlightId());

		if (flag == true) {
			Connection con = SingleTonConnection.getInstance().getConnection();
			String cmdCustIns = "update flights set CompanyName= ?, source=?, destination=? ,departureDate=?,departureTime =?,ArrivalTime=?,Price =?,seats=? where FlightID=?";
			try {
				PreparedStatement pst = con.prepareStatement(cmdCustIns);

				pst.setString(1, fAdmin.getCompanyName());
				pst.setString(2, fAdmin.getSource());
				pst.setString(3, fAdmin.getDestination());
				pst.setDate(4, fAdmin.getDepartureDate());
				pst.setString(5, fAdmin.getDepartureTime());
				pst.setString(6, fAdmin.getArrivalTime());
				pst.setDouble(7, fAdmin.getPrice());
				pst.setInt(8, fAdmin.getSeats());
				pst.setString(9, fAdmin.getFlightId());
				int n = pst.executeUpdate();
				if (n > 0) {
					msg = true;
				}

			} catch (SQLException e) {
				
				// TODO Auto-generated catch block
				e.printStackTrace();
			//	logger.error(PropertyUtil.getMessage(e.getMessage()));
			}
		}

		return msg;
	}

	public boolean flightExistsDelete(String flightId) throws ValidationException,DatabaseException {
		boolean flag = false;
		String userCmd = "select flightId from flights where flightId=?";
		Connection con = SingleTonConnection.getInstance().getConnection();
		try {
			PreparedStatement pst = con.prepareStatement(userCmd);
			pst.setString(1, flightId);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				flag = true;
			}
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		System.out.println("exist" + flag);
		return flag;
	}

	public boolean deleteFlights(Flights objFlights) throws ValidationException, DatabaseException {
		String flightId = objFlights.getFlightId();
		boolean flag = flightExistsDelete(flightId);
		boolean msg = false;
		if (flag == true) {
			String query = "delete from Flights where flightId=?";
			Connection con = SingleTonConnection.getInstance().getConnection();
			/* ResultSet rs=null; */
			PreparedStatement pst;
			try {
				pst = con.prepareStatement(query);
				pst.setString(1, flightId);
				int n = pst.executeUpdate();
				if (n > 0) {
					msg = true;
				}
			} catch (SQLException e) {
				
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));

			}
		}
		return msg;

	}
	
	
	  


}
