package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cts.beans.Passenger;
import com.cts.datasource.SingleTonConnection;
import com.cts.utilities.PropertyUtil;

public class PassengerDetailsDao {

	private  static Logger logger = Logger.getLogger(PassengerDetailsDao.class);
	
	public String deletePassenger(){
		String cmd="delete from Passenger where pnr=?";
		Connection con = SingleTonConnection.getInstance().getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(cmd);
			pst.setString(1,getPnr());
			pst.executeUpdate();
			return "Passenger Details Deleted...";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
			return e.getMessage();
		}
	}
	
	public String getPnr() {
		String cmd="select max(pnr) pnr from Passenger";
		String pnr="";
		Connection con = SingleTonConnection.getInstance().getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(cmd);
			ResultSet rs=pst.executeQuery(); 
			rs.next();
			pnr=rs.getString("pnr");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		return pnr;
	}
	
	public String generatePnr() {
		String cmd="select count(*) cnt from Passenger";
		String pnr="";
		ResultSet rs=null;
		PreparedStatement pst=null;
		Connection con = SingleTonConnection.getInstance().getConnection();
		try {
			pst=con.prepareStatement(cmd);
			rs=pst.executeQuery();
			rs.next();
			int cnt=rs.getInt("cnt");
			if(cnt==0){
				pnr="P001";
			}
			else {
				cmd="select pnr from Passenger";
				pst=con.prepareStatement(cmd);
				rs=pst.executeQuery();
				while(rs.next()){
					pnr=rs.getString("pnr");
				}
				int p=Integer.parseInt(pnr.substring(1));
				p++;
				if(p >=1 && p <=9){
					pnr="P00"+p;
				}
				if(p >= 10 && p <= 99){
					pnr="P0"+p;
				}
				if(p >= 100 && p <= 999){
					pnr="P"+p;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		return pnr;
	}
	
	public Passenger searchPassenger(String pnr){
		Connection con = SingleTonConnection.getInstance().getConnection();
		Passenger p=null;
		String cmd="select * from passenger where pnr=?";
		try {
			PreparedStatement pst=con.prepareStatement(cmd);
			pst.setString(1,pnr);
			ResultSet rs=pst.executeQuery();
			if(rs.next()){
				p=new Passenger(); 
				p.setFlightId(rs.getString("flightid"));
				p.setAge(rs.getString("age"));
				p.setGender(rs.getString("gender"));
				p.setJourneyDate(rs.getDate("journeyDate"));
				p.setPnr(rs.getString("pnr"));
				p.setPassengerName(rs.getString("passengerName"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		return p;
	}
	
	public String addPassenger(Passenger p){
		Connection con = SingleTonConnection.getInstance().getConnection();
		String cmd="insert into Passenger(PassengerName,age,gender,FlightID,journeyDate,pnr) values(?,?,?,?,?,?)";
		String res="";
		try {
			PreparedStatement pst=con.prepareStatement(cmd);
			pst.setString(1,p.getPassengerName());
			pst.setString(2,p.getAge());
			pst.setString(3,p.getGender());
			pst.setString(4,p.getFlightId());
			pst.setDate(5,p.getJourneyDate());
			pst.setString(6,generatePnr());
			pst.executeUpdate();
			res="Passenger Details Stored Successfully...";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			res=e.getMessage();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		return res;
	}
}
