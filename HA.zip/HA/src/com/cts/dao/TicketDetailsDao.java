package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cts.beans.Ticket;
import com.cts.datasource.SingleTonConnection;

public class TicketDetailsDao {
	 public List<Ticket> showTickets(String customerName) {
		   Connection con = SingleTonConnection.getInstance().getConnection();
			String cmdcount="select count(*) cnt from bookedhistory where CustomerName=?";
			String sqlCmd = "select * from bookedhistory where CustomerName=?";
			List<Ticket> ticket=new ArrayList<Ticket>();
			try {
				PreparedStatement pst = con.prepareStatement(cmdcount);
				System.out.println(customerName);

				pst.setString(1, customerName);
				ResultSet rs = pst.executeQuery();
				rs.next();
				int count = rs.getInt("cnt");
				if (count == 0) {
					ticket = null;
				}
				else {
					//ticket = new Ticket[count];
					pst = con.prepareStatement(sqlCmd);
					pst.setString(1, customerName);
					
					rs = pst.executeQuery();
					Ticket t = null;
					int i = 0;
					int s=0;
					while (rs.next()) {
					
					
						t = new Ticket();
					
						t.setFlightId(rs.getString("FlightID"));
						t.setCustomerName(rs.getString("customerName"));
						t.setNoOfPassengers(rs.getInt("NoOfPassengers"));
						t.setBillAmount(rs.getDouble("BillAmount"));
						t.setDateOfJourney(rs.getDate("dateOfJourney"));
						t.setTicketNo(rs.getString("TicketNo"));
						t.setBookStatus(rs.getString("BookStatus"));
						t.setSource(rs.getString("Source"));
						t.setDestination(rs.getString("Destination"));
						

						ticket.add(t);
						i++;
					
					}
				
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return ticket;	
				
			
		}


}
