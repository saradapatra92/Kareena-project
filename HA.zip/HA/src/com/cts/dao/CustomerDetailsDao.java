package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import java.text.SimpleDateFormat;

import com.cts.beans.Customer;
import com.cts.datasource.SingleTonConnection;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;
import com.cts.utilities.PropertyUtil;

public class CustomerDetailsDao {

	private  static Logger logger = Logger.getLogger(CustomerDetailsDao.class);
	public boolean authenticate(String email,String passWord) throws ValidationException,DatabaseException{
		boolean flag=false;
		String sqlCmd="select email from customer where email=? AND password=?";
		Connection con = SingleTonConnection.getInstance().getConnection();
		try {
			PreparedStatement pst = con.prepareStatement(sqlCmd);
			pst.setString(1,email);
			pst.setString(2,passWord);
			ResultSet rs=pst.executeQuery();
			if(rs.next()){
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		return flag;
	}
	
	public boolean userExists(String email)  throws ValidationException,DatabaseException {
		boolean flag = false;
		String userCmd = "select email from Customer where email=?";
		Connection con = SingleTonConnection.getInstance().getConnection();
		try {
			PreparedStatement pst = con.prepareStatement(userCmd);
			pst.setString(1, email);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				flag = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		return flag;
	}
	
	public String getCustomerName(String email) throws ValidationException,DatabaseException {
		String firstname="";
		String userCmd = "select firstName from Customer where email=?";
		Connection con = SingleTonConnection.getInstance().getConnection();
		try {
			PreparedStatement pst = con.prepareStatement(userCmd);
			pst.setString(1, email);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				firstname=rs.getString(1);
				System.out.println(firstname);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		return firstname;
	}

	public boolean addCustomer(Customer objCustomer) throws ValidationException, DatabaseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		boolean flag = userExists(objCustomer.getEmail());
		boolean  msg = true;
		if (flag == false) {
			Connection con = SingleTonConnection.getInstance().getConnection();
			String cmdCustIns = "Insert into Customer(firstName,lastName,email,password,dateofBirth,"
					+ "gender,contactNo,ssnType,SsnNumber,Address,City,State,Country"
					+ ") values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
			try {
				PreparedStatement pst = con.prepareStatement(cmdCustIns);
				pst.setString(1, objCustomer.getFirstName());
				pst.setString(2, objCustomer.getLastName());
				pst.setString(3, objCustomer.getEmail());
				pst.setString(4, objCustomer.getPassWord());

				pst.setDate(5, objCustomer.getDateofBirth());
				pst.setString(6, objCustomer.getGender());
				pst.setString(7, objCustomer.getContactNo());
				pst.setString(8, objCustomer.getSsnType());
				pst.setString(9, objCustomer.getSsnNumber());
				pst.setString(10, objCustomer.getAddress());
				pst.setString(11, objCustomer.getCity());
				pst.setString(12, objCustomer.getState());
				pst.setString(13, objCustomer.getCountry());
				int n=pst.executeUpdate();
				if(n>0)
				{
					msg=true;
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));
			}
		} else {
			msg = false;
		}
		return msg;
	}
}
