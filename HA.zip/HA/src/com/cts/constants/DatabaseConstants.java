package com.cts.constants;

public class DatabaseConstants {
	
	public static final String DBPROPERTIES = "resources/db.properties";
	public static final String DATABASEDRIVER = "database.driver";
	public static final String DATABASEURL = "database.url";
	public static final String DATABASEUSERNAME = "database.username";	
	public static final String DATABASEPASSWORD = "database.password";	

}
