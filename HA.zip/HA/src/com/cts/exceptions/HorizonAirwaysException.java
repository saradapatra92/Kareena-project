package com.cts.exceptions;

public class HorizonAirwaysException extends Exception {

	String message=null;
	public HorizonAirwaysException(String message){
		this.message=message;		
	}
	
	public String getMessage()
	{
		return message;
	}
}