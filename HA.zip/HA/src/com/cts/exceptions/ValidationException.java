package com.cts.exceptions;

public class ValidationException extends Exception{

	String message=null;
	public ValidationException(String message){
		this.message=message;
		
	}
	
	public String getMessage()
	{
		return message;
	}
	
	
}
