package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cts.beans.Flights;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;
import com.cts.helper.FlightDetailsHelper;

/**
 * Servlet implementation class FlightDeletionServlet
 */
public class FlightDeletionServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(FlightDeletionServlet.class);
	   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FlightDeletionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean result=false;
		
		System.out.println("s log1");
		logger.debug("DeleteFlight Servlet : Delete Flight");
		// TODO Auto-generated method stub
		System.out.println("s log2");

		Flights objFlights=new Flights();
		String flightid=(String)request.getParameter("flightid");
		objFlights.setFlightId(flightid);
		//objFlights.setFlightId(request.getParameter("flightid"));
		//FlightDetailsDao objDao=new FlightDetailsDao();
		
		
		try {
			result = FlightDetailsHelper.deleteFlights(objFlights);
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error %%%%" + e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error %%%%" + e);
		}
	//	boolean result=objDao.deleteFlights(objFlights) ;
		PrintWriter out=response.getWriter();
		//out.println(result);
		if(result==true)
		{
			System.out.println("afgh");
			
			RequestDispatcher rd=request.getRequestDispatcher("DeleteFlight.jsp");
			rd.include(request, response); 
		
			out.println("<script>document.getElementById('result1').style.visibility = 'visible';</script>");
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("DeleteFlight.jsp");
			rd.include(request, response); 
		
			out.println("<script>document.getElementById('result2').style.visibility = 'visible';</script>");
		}
		logger.debug("DeleteFlight Servlet execute Successfully...");
	}

}
