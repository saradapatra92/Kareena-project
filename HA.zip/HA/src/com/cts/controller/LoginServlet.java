package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.dao.CustomerDetailsDao;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;
import com.cts.helper.CustomerDetailsHelper;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(LoginServlet.class);
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.debug("LoginServlet Servlet : LoginServlet Flight");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		CustomerDetailsDao objDao = new CustomerDetailsDao();
		String firstname="";
		try {
			firstname = objDao.getCustomerName(email);
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error %%%%" + e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error %%%%" + e);
		}
		boolean result=CustomerDetailsHelper.authenticate(email, password);
		System.out.println(result);
		//boolean result = objDao.authenticate(email, password);
		if (result == true) {
			HttpSession session = request.getSession(true);
			if (firstname == null) {
				session.setAttribute("user", " ");
			} else {
				session.setAttribute("user", firstname);
			}
			if(email.equals("admin@gmail.com") && password.equals("admin@123")){
				RequestDispatcher disp = request.getRequestDispatcher("AdminHome.html");
				disp.forward(request, response);
			}
			else{
			String source=(String)session.getAttribute("source");
			if(source==null){
			
			RequestDispatcher disp = request.getRequestDispatcher("Search.jsp");
			disp.forward(request, response);
			}
			else {
				HttpSession ses=request.getSession(true);
				String name=(String)ses.getAttribute("flightId");
				PrintWriter out = response.getWriter();
				out.println("name is  " +name);
				RequestDispatcher disp = request.getRequestDispatcher("BookFlightDup.jsp");
				disp.forward(request, response);
			}
			}
		} else {
			PrintWriter out = response.getWriter();
			RequestDispatcher disp = request.getRequestDispatcher("Login.jsp");
			disp.include(request, response);
			out.println("<script>document.getElementById('result').style.visibility = 'visible';</script>");
		}

		logger.debug("LoginServlet execute Successfully...");
		}

}
