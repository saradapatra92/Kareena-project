package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cts.beans.Flights;
import com.cts.helper.FlightDetailsHelper;

/**
 * Servlet implementation class NewFlightServlet
 */
public class NewFlightServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(NewFlightServlet.class);
	    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewFlightServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.debug("Inside Flights Servlet : Adding Flight Details");
		Flights objFlights=new Flights();
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy"); 
		java.util.Date dateStr=null;
		try {
			dateStr = formatter.parse(request.getParameter("date"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error %%%%" + e);
		}

		java.sql.Date dateDB = new java.sql.Date(dateStr.getTime());
		objFlights.setFlightId(request.getParameter("id"));
		objFlights.setCompanyName(request.getParameter("name"));
		objFlights.setSource(request.getParameter("from"));
		objFlights.setDestination(request.getParameter("to"));
		//String dt=request.getParameter("date");
		objFlights.setDepartureDate(dateDB);
		objFlights.setArrivalTime(request.getParameter("arrival_time"));
		objFlights.setDepartureTime(request.getParameter("depart_time"));
		objFlights.setPrice(Double.parseDouble(request.getParameter("price")));
		objFlights.setSeats(Integer.parseInt(request.getParameter("seats")));
		
		//FlightDetailsDao objflightDetailsDao=new FlightDetailsDao();
		boolean res=FlightDetailsHelper.addFlights(objFlights);
		//boolean res=objflightDetailsDao.addFlights(objFlights);
		PrintWriter out=response.getWriter();
		//out.println(res);
		
		if(res==true){
			RequestDispatcher rd=request.getRequestDispatcher("AddFlight.jsp");
			rd.include(request, response); 
		
			out.println("<script>document.getElementById('result1').style.visibility = 'visible';</script>");
		}
		else{
			/*System.out.println("Fail resp");
			response.sendRedirect("AdminHome.html");*/
			
			RequestDispatcher rd=request.getRequestDispatcher("AddFlight.jsp");
			rd.include(request, response); 
		
			out.println("<script>document.getElementById('result2').style.visibility = 'visible';</script>");
		}
		logger.debug("FlightAdd Servlet execute Successfully...");


	}


}
