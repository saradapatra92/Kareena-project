package com.cts.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cts.beans.Flights;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;
import com.cts.helper.FlightDetailsHelper;

/**
 * Servlet implementation class FlightSearch
 */
public class FlightSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(FlightSearch.class);
	      
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FlightSearch() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Flights flight=null;
		logger.debug("SearchFlight Servlet : Search about Flight Details");
		String flightid = request.getParameter("flightid");
		//FlightDetailsDao dao=new FlightDetailsDao();
		
		try {
			flight = FlightDetailsHelper.searchFlight(flightid);
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error %%%%" + e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error %%%%" + e);
		}
	//	Flights flight=dao.searchFlight(flightid);
		if(flight==null){
			RequestDispatcher d1=request.getRequestDispatcher("SearchError.html");
			d1.forward(request, response);
		}
		else{
			RequestDispatcher d=request.getRequestDispatcher("SearchedFlightDetail.jsp");
			request.setAttribute("SEARCHED FLIGHT", flight);
			d.forward(request, response);
		}
		logger.debug("SearchFlight executed Successfully...");
		
	}

}
