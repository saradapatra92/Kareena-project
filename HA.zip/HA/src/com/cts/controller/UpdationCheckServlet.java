package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.beans.Flights;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;
import com.cts.helper.FlightDetailsHelper;

/**
 * Servlet implementation class UpdationCheckServlet
 */
public class UpdationCheckServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(UpdationCheckServlet.class);
	   
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdationCheckServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.debug("CheckUpdate Servlet : Status Checking for Flight");
		String flightid = request.getParameter("flightid");
		
		HttpSession sessionFlightId=request.getSession();
		sessionFlightId.setAttribute("FlightIdUp", flightid);
		
		PrintWriter out=response.getWriter();
		//FlightDetailsDao dao=new FlightDetailsDao();
		Flights flight=null;
		try {
			flight = FlightDetailsHelper.searchFlight(flightid);
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error %%%%" + e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error %%%%" + e);
		}
		//Flights flight=dao.searchFlight(flightid);
		if(flight==null){
			
			RequestDispatcher rd=request.getRequestDispatcher("AdminUpdateId.jsp");
			rd.include(request, response); 
		
			out.println("<script>document.getElementById('result1').style.visibility = 'visible';</script>");
		}
		else{
			response.sendRedirect("UpdateFlight.jsp");
		}
		logger.debug("FlightStatus Servlet execute Successfully...");
	}

}
