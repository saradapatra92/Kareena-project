package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cts.beans.Flights;
import com.cts.helper.FlightDetailsHelper;

/**
 * Servlet implementation class FlightUpdationServlet
 */
public class FlightUpdationServlet extends HttpServlet {
	private static Logger logger = Logger.getLogger(FlightUpdationServlet.class);
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FlightUpdationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		java.util.Date dateStr=null;
		logger.debug("UpdateFlightServlet : Calling flightUpdate Method");
		Flights fAdmin=new Flights();
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy"); 
		
		try {
			dateStr = formatter.parse(request.getParameter("date"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		java.sql.Date dateDB = new java.sql.Date(dateStr.getTime());
		fAdmin.setFlightId(request.getParameter("id"));
		fAdmin.setCompanyName(request.getParameter("name"));
		fAdmin.setSource(request.getParameter("from"));
		fAdmin.setDestination(request.getParameter("to"));
		//String dt=request.getParameter("date");
		fAdmin.setDepartureDate(dateDB);
		fAdmin.setArrivalTime(request.getParameter("arrival_time"));
		fAdmin.setDepartureTime(request.getParameter("depart_time"));
		fAdmin.setPrice(Double.parseDouble(request.getParameter("price")));
		fAdmin.setSeats(Integer.parseInt(request.getParameter("seats"))); 
		System.out.println("Flight ID  " +fAdmin.getFlightId());
		System.out.println("Company Name  " +fAdmin.getCompanyName());
		System.out.println("Source  " +fAdmin.getSource());
		System.out.println("Destination  " +fAdmin.getDestination());
		System.out.println("Departure Date  " +dateDB);
		System.out.println("Arrival Time  " +fAdmin.getArrivalTime());
		System.out.println("Departure Time  " +fAdmin.getDepartureTime());
		System.out.println("Seats  " +fAdmin.getSeats());
		System.out.println("Price  " +fAdmin.getPrice());
		
		
		//FlightDetailsDao objflightDetailsDao=new FlightDetailsDao(); 
		
		boolean res=FlightDetailsHelper.flightUpdate(fAdmin);
		//boolean  res=objflightDetailsDao.flightUpdate(fAdmin);
		PrintWriter out=response.getWriter();
		//out.println(res);
		if(res==true){
			//	RequestDispatcher disp=request.getRequestDispatcher("AddFlight.html");
				//disp.forward(request, response);
				
			RequestDispatcher rd=request.getRequestDispatcher("AdminUpdateId.jsp");
			rd.include(request, response); 
		
			out.println("<script>document.getElementById('result2').style.visibility = 'visible';</script>");
			}
			else{
				
				response.sendRedirect("UpdateError.html");
			}

		logger.debug("UpdateFlightServlet execute Successfully...");
	}


}
