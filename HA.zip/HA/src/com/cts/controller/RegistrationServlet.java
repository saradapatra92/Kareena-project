package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cts.beans.Customer;
import com.cts.helper.CustomerDetailsHelper;

/**
 * Servlet implementation class RegistrationServlet
 */
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	private static Logger logger = Logger.getLogger(RegistrationServlet.class);
	
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.debug("Inside CustomerAdd Servlet : Adding Customer Details");
		Customer objCustomer=new Customer();
		RequestDispatcher d1,d2;
		//		SimpleDateFormat sdf=new SimpleDateFormat("MM-dd-YYYY");
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		String sdt=request.getParameter("dateOfBirth");
		System.out.println("Actual Date is  " +sdt);

		// your template here
		java.util.Date dateStr=null;
		try {
			dateStr = formatter.parse(sdt);
			System.out.println("Date is  " +dateStr);

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error %%%%" + e);
		}
		java.sql.Date dateDB = new java.sql.Date(dateStr.getTime());
		objCustomer.setFirstName(request.getParameter("firstName"));
		objCustomer.setLastName(request.getParameter("lastName"));
		objCustomer.setEmail(request.getParameter("email"));
		objCustomer.setPassWord(request.getParameter("password"));
		String dt=request.getParameter("dateOfBirth");

		objCustomer.setDateofBirth(dateDB);
		objCustomer.setGender(request.getParameter("gender"));
		objCustomer.setContactNo(request.getParameter("contactNo"));
		objCustomer.setSsnType(request.getParameter("ssnType"));
		objCustomer.setSsnNumber(request.getParameter("ssnNo"));
		objCustomer.setAddress(request.getParameter("address"));
		objCustomer.setCity(request.getParameter("city"));
		objCustomer.setState(request.getParameter("state"));
		objCustomer.setCountry(request.getParameter("country"));

		// CustomerDetailsDao objuUserDetailsDao=new CustomerDetailsDao();
		boolean res=CustomerDetailsHelper.addCustomer(objCustomer); 

		//boolean res=objuUserDetailsDao.addCustomer(objCustomer);
		PrintWriter out=response.getWriter();
		//	out.print("abc");
		if(res==true){
			RequestDispatcher disp=request.getRequestDispatcher("Login.html");
			disp.forward(request, response);
		}
		else{


			request.setAttribute("msg", "User already exist");
			request.getRequestDispatcher("SignNew.jsp").forward(request, response);
		}
		logger.debug("CustomerAdd Servlet execute Successfully...");
	}
}
